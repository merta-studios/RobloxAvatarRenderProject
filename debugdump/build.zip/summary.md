# Avatar-Render: `SunsetSiya`

* UserId: **9767435332**
* Avatar-Typ: **R15**
* Quelle: `https://avatar.roblox.com/v1/users/9767435332/avatar`
* Teile: **16** (Accessoires: 8, Körperteile aus echten Meshes: 3, Texturen: 12, fehlgeschlagen: 0, Animationen ignoriert: 8)
* Höhe: 4,72 Studs (typisch 5–6)

## Teile

| Teil | Typ | Farbe | Notiz |
| --- | --- | --- | --- |
| rechts_bein | body | `#999797` |  |
| links_bein | body | `#999797` |  |
| torso | body | `#62666b` | Echtes Mesh aus RBXM (Mesh-Asset 8997174058), 2 R15-Segmente per RBXM-Position zusammengefuehrt |
| rechts_arm | body | `#62666b` | Echtes Mesh aus RBXM (Mesh-Asset 8997173999), 3 R15-Segmente per RBXM-Position zusammengefuehrt |
| links_arm | body | `#62666b` | Echtes Mesh aus RBXM (Mesh-Asset 8997174089), 3 R15-Segmente per RBXM-Position zusammengefuehrt |
| hals | body | `#c7ac78` |  |
| kopf_mesh | body | `#c7ac78` | Echtes Kopf-Mesh des Avatars (2538 Faces, Mesh-BBox 1,198x1,202x1,198, Zentrum 0,00/0,00/0,00, RBXM-Groesse 1,000x1,000x1,000 Studs) |
| tshirt_decal | decal | `#ffffff` | T-Shirt-Grafik als Dekal auf der Brust (UV 0..1) |
| Handle (77320963564953) | accessory | `#dff4ff` | Jacke (Layered): als Huelle um den Koerper gezogen (1,07x1,70x1,04 Studs), Anker 'torso_shell' |
| Handle (81104804294334) | accessory | `#dff4ff` | Hals-Accessoire: RBXM-Groesse 1,00x1,00x1,00 Studs, form-erhaltend skaliert (Originalgroesse 0,7x0,7x0,8 Studs), Anker 'neck' |
| Handle (92049900772784) | accessory | `#dff4ff` | Hueft-Accessoire: RBXM-Groesse 1,00x1,00x1,00 Studs, form-erhaltend skaliert (Originalgroesse 3,5x2,4x3,8 Studs), Anker 'waist' |
| Handle (128875987262000) | accessory | `#dff4ff` | Hut: RBXM-Groesse 1,00x1,00x1,00 Studs, form-erhaltend skaliert (Originalgroesse 0,8x0,8x0,2 Studs), Anker 'head_top' |
| Handle (130937495030414) | accessory | `#dff4ff` | Hut: RBXM-Groesse 1,00x1,00x1,00 Studs, form-erhaltend skaliert (Originalgroesse 1,5x0,4x1,1 Studs), Anker 'head_top' |
| Handle (134546685450169) | accessory | `#dff4ff` | Haare: RBXM-Groesse 1,05x1,05x1,05 Studs, form-erhaltend skaliert (Originalgroesse 1,8x2,8x1,6 Studs), Anker 'head_top' |
| Handle (135192057418760) | accessory | `#dff4ff` | Brust-Accessoire: RBXM-Groesse 1,00x1,00x1,00 Studs, form-erhaltend skaliert (Originalgroesse 1,7x1,4x1,3 Studs), Anker 'chest_front' |
| Handle (135595423258275) | accessory | `#dff4ff` | Hut: RBXM-Groesse 1,00x1,01x1,01 Studs, form-erhaltend skaliert (Originalgroesse 1,3x0,8x1,5 Studs), Anker 'head_top' |

## Ignoriert (Animationen/Audio, werden nicht gerendert)

Mage Run (RunAnimation), Mage Walk (WalkAnimation), Mage Idle (IdleAnimation), Oldschool Fall (FallAnimation), Oldschool Jump (JumpAnimation), Oldschool Climb (ClimbAnimation), Default Mood (MoodAnimation), adidas Community Animation Pack (SwimAnimation)

## Hinweise

* Proportionen: 'links_bein' auf 0,50x1,80x0,82 Studs begrenzt (Beine nicht breiter als der Torso).
* Proportionen: 'rechts_bein' auf 0,50x1,80x0,82 Studs begrenzt (Beine nicht breiter als der Torso).
* Proportionen: 'links_arm' auf 0,55x1,70x0,73 Studs begrenzt (Armbreite/-laenge relativ zum Torso).
* Proportionen: 'rechts_arm' auf 0,55x1,70x0,73 Studs begrenzt (Armbreite/-laenge relativ zum Torso).
* Kopf-Textur wirkt wie eine dunkle Zusatz-Map (Roughness/Normal) - der Kopf nutzt die Koerperfarbe des Avatars.
* Kopf wurde durch das echte Head-Mesh des Avatars ersetzt.
